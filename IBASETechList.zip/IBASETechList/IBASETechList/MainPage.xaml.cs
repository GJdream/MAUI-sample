﻿using IBASETechList.Model;
using IBASETechList.Service;
using static Android.Content.ClipData;

namespace IBASETechList;

public partial class MainPage : ContentPage
{
    private ApiService apiService = new ApiService();

    public MainPage()
	{
		InitializeComponent();
        LoadData();
    }

    private async void LoadData()
    {
        List<Todo> items = await apiService.GetItemsAsync();
        itemListView.ItemsSource = items;
        if(items.Count == 0) {
           await DisplayAlert("To Do List", "No Data Found", "OK");
        }
    }

    private void itemListView_ItemTapped(object sender, ItemTappedEventArgs e)
    {
        Console.WriteLine(sender);
        Console.WriteLine(e.Item.ToString());

        Todo item = (Todo)e.Item;
        if(item != null )
        {
            TodoDetailPage todoPage = new TodoDetailPage(item);
            Navigation.PushAsync(todoPage);
        }
    }
}

