﻿using IBASETechList.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static Android.Content.ClipData;

namespace IBASETechList.Service
{
    class ApiService
    {
        private readonly HttpClient _httpClient;

        public ApiService()
        {
            _httpClient = new HttpClient
            {
                BaseAddress = new Uri("https://jsonplaceholder.typicode.com/"), 
            };
        }

        public async Task<List<Todo>> GetItemsAsync()
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<List<Todo>>("todos");

                if (response != null)
                {
                    return response;
                }
                else
                {
                    // Handle the case where the response is null (e.g., empty result)
                    return new List<Todo>();
                }
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine("HTTP request error: " + ex.Message);
                return new List<Todo>();
            }
            catch (JsonException ex)
            {
                Console.WriteLine("JSON deserialization error: " + ex.Message);
                return new List<Todo>();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return new List<Todo>();
            }
        }
    }
}
