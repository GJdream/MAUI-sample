using IBASETechList.Model;

namespace IBASETechList;

public partial class TodoDetailPage : ContentPage
{
    public TodoDetailPage(Todo todo)
    {
        InitializeComponent();
        BindingContext = todo;
    }

}