I have created this Sample in Xamarin Latest technology MAUI. 

To Run this project

Please Open IBASETechList.sln in Visual Studio 2022 (make sure MAUI installed )

Attach any device and Run it

Ghanshyam Jain
